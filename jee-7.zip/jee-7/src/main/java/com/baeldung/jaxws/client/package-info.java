@javax.xml.bind.annotation.XmlSchema(namespace = "http://bottomup.server.jaxws.baeldung.com/")
package com.baeldung.jaxws.client;
