package com.baeldung.arquillian;

public class ConvertToLowerCase {
    public String convert(String word){
        return word.toLowerCase();
    }
}
