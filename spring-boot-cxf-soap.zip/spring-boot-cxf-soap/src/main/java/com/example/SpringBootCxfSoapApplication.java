package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
//@ImportResource({ "classpath:META-INF/cxf/cxf.xml" })
public class SpringBootCxfSoapApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootCxfSoapApplication.class, args);
    }
}

