package com.example.soap;

import org.springframework.stereotype.Service;

import javax.jws.WebService;

@Service
@WebService(name = "HelloWorldService",
        serviceName = "HelloWorldService",
        portName = "HelloWorldPort",
        targetNamespace = "http://soap.example.com/")
public class HelloWorldServiceImpl implements HelloWorldService {

    public String sayHello(String name) {
        return "Hello, " + name + "!";
    }
}