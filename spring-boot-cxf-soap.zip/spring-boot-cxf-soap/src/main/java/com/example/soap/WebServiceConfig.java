package com.example.soap;
//
//
//import org.apache.cxf.Bus;
//import org.apache.cxf.bus.spring.SpringBus;
//import org.apache.cxf.jaxb.JAXBDataBinding;
//import org.apache.cxf.jaxws.EndpointImpl;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.util.StringUtils;
//
//import javax.xml.bind.JAXBContext;
//import javax.xml.ws.Endpoint;
//
//
//@Configuration
//@ComponentScan(basePackages = "com.example.soap")
public class WebServiceConfig {

//    @Autowired
//    private Bus bus;
//
//    @Autowired
//    HelloWorldService helloWorldService;
//
//    @Bean
//    public Endpoint endpoint() {
//        EndpointImpl endpoint = new EndpointImpl(bus, helloWorldService);
//        endpoint.publish("/hello");
//        return endpoint;
//    }
//    @Bean
//    public JAXBDataBinding jaxbDataBinding() {
//        JAXBDataBinding jaxbDataBinding = new JAXBDataBinding();
//        jaxbDataBinding.setJaxbAnnotationIntrospector(new JaxbAnnotationIntrospector(jaxbDataBinding));
//        return jaxbDataBinding;
//    }
//
//    @Bean
//    public JacksonJsonProvider jacksonJsonProvider() {
//        return new JacksonJsonProvider();
//    }
//
//    @Bean
//    public JAXBDataBinding jaxbDataBinding() {
//        JAXBDataBinding jaxbDataBinding = new JAXBDataBinding();
//        // Customize the JAXBContext to include the package containing the HelloWorldService interface.
//        JAXBContext context = null;
//        try {
//            String packageToScan = HelloWorldService.class.getPackage().getName();
//            context = JAXBContextInitializer.createJAXBContext(StringUtils.split(packageToScan, " "), null, getClass().getClassLoader(), new DefaultServiceConfiguration());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        jaxbDataBinding.setContext(context);
//        return jaxbDataBinding;
//    }
}