package com.redhat.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class PAM7SpringBootApp {

    public static void main(String[] args) {
        SpringApplication.run(PAM7SpringBootApp.class, args);
    }


}
