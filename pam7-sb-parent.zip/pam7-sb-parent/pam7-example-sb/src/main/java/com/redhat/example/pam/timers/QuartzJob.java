package com.redhat.example.pam.timers;

import com.redhat.example.pam.DeploymentUnitBuilder;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

@Component
public class QuartzJob extends QuartzJobBean {

    @Autowired
    private DeploymentUnitBuilder deploymentUnitBuilder;

//    @Override
//    public void execute(JobExecutionContext ctx) {
//        JobDataMap dataMap = ctx.getJobDetail().getJobDataMap();
//        QuartzJobParameter param = (QuartzJobParameter) dataMap.get("param");
//        System.out.println("Quartz job executed - " + deploymentUnitBuilder.getDeploymentUnit().toString());
//        System.out.println("Quartz job executed - getFirstParameter " + param.getFirstParameter());
//        System.out.println("Quartz job executed - getSecondParameter " + param.getSecondParameter());
//    }

    @Override
    protected void executeInternal(JobExecutionContext ctx) throws JobExecutionException {
        JobDataMap dataMap = ctx.getJobDetail().getJobDataMap();
        QuartzJobParameter param = (QuartzJobParameter) dataMap.get("param");
        System.out.println("Quartz job executed - " + deploymentUnitBuilder.getDeploymentUnit().toString());
        System.out.println("Quartz job executed - getFirstParameter " + param.getFirstParameter());
        System.out.println("Quartz job executed - getSecondParameter " + param.getSecondParameter());

    }
}
