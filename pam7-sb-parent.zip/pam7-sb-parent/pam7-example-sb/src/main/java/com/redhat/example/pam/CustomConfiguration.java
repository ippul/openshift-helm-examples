package com.redhat.example.pam;

import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.spi.TriggerFiredBundle;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.quartz.QuartzProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.AdaptableJobFactory;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.Properties;

@Configuration
@EnableConfigurationProperties(QuartzProperties.class)
@AutoConfigureAfter({ SchedulerFactoryBean.class })
public class CustomConfiguration {
    @Bean("ApplicationScheduler")
    public Scheduler customScheduler(@Qualifier("customSchedulerFactoryBean") SchedulerFactoryBean factory) throws SchedulerException {
        Scheduler scheduler = factory.getScheduler();
        System.out.println("Scheduler name: " + scheduler.getSchedulerName());
        scheduler.start();
        return scheduler;
    }

    @Bean("customSchedulerFactoryBean")
    public SchedulerFactoryBean customSchedulerFactoryBean(QuartzJobFactory quartzJobFactory, DataSource dataSource, @Qualifier("quartzDataSource") DataSource quartzDataSource) throws IOException {
        SchedulerFactoryBean factory = new SchedulerFactoryBean();
        Properties properties = quartzProperties();
//        properties.replace("org.quartz.scheduler.instanceName", "ApplicationScheduler");
//        properties.replace("org.quartz.threadPool.threadNamePrefix", "application-scheduler");
        factory.setQuartzProperties(properties);
        factory.setDataSource(dataSource);
        factory.setNonTransactionalDataSource(quartzDataSource);
        factory.setJobFactory(quartzJobFactory);
        return factory;
    }

    public Properties quartzProperties() throws IOException {
        PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
        propertiesFactoryBean.setLocation(new ClassPathResource("/application-quartz.properties"));
        propertiesFactoryBean.afterPropertiesSet();
        return propertiesFactoryBean.getObject();
    }

    @Component("quartzJobFactory")
    public static class QuartzJobFactory extends AdaptableJobFactory {

        private final AutowireCapableBeanFactory capableBeanFactory;

        public QuartzJobFactory(AutowireCapableBeanFactory capableBeanFactory) {
            this.capableBeanFactory = capableBeanFactory;
        }

        @Override
        protected Object createJobInstance(TriggerFiredBundle bundle) throws Exception {
            Object jobInstance = super.createJobInstance(bundle);
            capableBeanFactory.autowireBean(jobInstance);
            return jobInstance;
        }
    }

}
