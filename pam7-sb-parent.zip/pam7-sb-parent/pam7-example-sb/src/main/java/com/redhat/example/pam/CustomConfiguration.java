package com.redhat.example.pam;

import org.quartz.*;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.autoconfigure.quartz.QuartzDataSource;
import org.springframework.boot.autoconfigure.quartz.QuartzProperties;
import org.springframework.boot.autoconfigure.quartz.SchedulerFactoryBeanCustomizer;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

@Configuration
@ConditionalOnClass({ Scheduler.class, SchedulerFactoryBean.class, PlatformTransactionManager.class })
@EnableConfigurationProperties(QuartzProperties.class)
@AutoConfigureAfter({ DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class,
        LiquibaseAutoConfiguration.class, FlywayAutoConfiguration.class })
public class CustomConfiguration
        //implements SchedulingConfigurer
{

//    @Override
//    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
//        ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
//        threadPoolTaskScheduler.setPoolSize(10);
//        threadPoolTaskScheduler.setThreadNamePrefix("app-scheduler-task-pool-");
//        threadPoolTaskScheduler.initialize();
//        taskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
//    }

//    @Bean("ApplicationSchedulerFactoryBean")
//    public SchedulerFactoryBean quartzScheduler(QuartzProperties properties, ObjectProvider<SchedulerFactoryBeanCustomizer> customizers, ObjectProvider<JobDetail> jobDetails, Map<String, Calendar> calendars, ObjectProvider<Trigger> triggers, ApplicationContext applicationContext) {
//        SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();
//        SpringBeanJobFactory jobFactory = new SpringBeanJobFactory();
//        jobFactory.setApplicationContext(applicationContext);
//        schedulerFactoryBean.setJobFactory(jobFactory);
//        if (properties.getSchedulerName() != null) {
//            schedulerFactoryBean.setSchedulerName(properties.getSchedulerName());
//        }
//
//        schedulerFactoryBean.setAutoStartup(properties.isAutoStartup());
//        schedulerFactoryBean.setStartupDelay((int)properties.getStartupDelay().getSeconds());
//        schedulerFactoryBean.setWaitForJobsToCompleteOnShutdown(properties.isWaitForJobsToCompleteOnShutdown());
//        schedulerFactoryBean.setOverwriteExistingJobs(properties.isOverwriteExistingJobs());
//        if (!properties.getProperties().isEmpty()) {
//            schedulerFactoryBean.setQuartzProperties(this.asProperties(properties.getProperties()));
//        }
//
//        schedulerFactoryBean.setJobDetails((JobDetail[])jobDetails.orderedStream().toArray((x$0) -> {
//            return new JobDetail[x$0];
//        }));
//        schedulerFactoryBean.setCalendars(calendars);
//        schedulerFactoryBean.setTriggers((Trigger[])triggers.orderedStream().toArray((x$0) -> {
//            return new Trigger[x$0];
//        }));
//        customizers.orderedStream().forEach((customizer) -> {
//            customizer.customize(schedulerFactoryBean);
//        });
//        return schedulerFactoryBean;
//    }

//    private Properties asProperties(Map<String, String> source) {
//        Properties properties = new Properties();
//        properties.putAll(source);
//        return properties;
//    }

    @Bean("ApplicationScheduler")
    public Scheduler customScheduler(SchedulerFactoryBean factory) throws SchedulerException {
        Scheduler scheduler = factory.getScheduler();
        System.out.println("Scheduler name: " + scheduler.getSchedulerName());
        scheduler.start();
        return scheduler;
    }

//    public Properties quartzProperties() throws IOException {
//        PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
//        propertiesFactoryBean.setLocation(new ClassPathResource("/quartz.properties"));
//        propertiesFactoryBean.afterPropertiesSet();
//        return propertiesFactoryBean.getObject();
//    }

}
