package com.redhat.example.pam.timers;

import java.io.Serializable;

public class QuartzJobParameter implements Serializable {

    private String firstParameter;

    private String secondParameter;

    public String getFirstParameter() {
        return firstParameter;
    }

    public void setFirstParameter(String firstParameter) {
        this.firstParameter = firstParameter;
    }

    public String getSecondParameter() {
        return secondParameter;
    }

    public void setSecondParameter(String secondParameter) {
        this.secondParameter = secondParameter;
    }
}
