package com.redhat.example.pam.timers;

import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.UUID;

@Component
public class TimerEventBean {

    @Autowired
    @Qualifier("ApplicationScheduler")
    private Scheduler scheduler;

    public void setTimer() throws SchedulerException {
        System.out.println("TimerEventBean - setTimer[in]");
        System.out.println("TimerEventBean - schedulerName: " +  scheduler.getSchedulerName());

        for(TriggerListener x : scheduler.getListenerManager().getTriggerListeners()){
            System.out.println("Trigger listener: " +  x.getName());
        }

        QuartzJobParameter param = new QuartzJobParameter();
        param.setFirstParameter("First parameter");
        param.setSecondParameter("Second parameter");

        JobDataMap dataMap = new JobDataMap();
        dataMap.put("param", param);
        JobDetail job = JobBuilder.newJob(QuartzJob.class)
                .withIdentity(UUID.randomUUID().toString(), "application-group")
                .usingJobData(dataMap)
                .build();

//        Date startAt = Date.from(LocalDateTime.now().plusSeconds(10).atZone(ZoneId.systemDefault()).toInstant());
        Date startAt = Date.from(LocalDateTime.now().plusSeconds(10).toInstant(ZoneOffset.UTC));
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
        System.out.println("TimerEventBean - Start at: " + simpleDateFormat.format(startAt));

        Trigger trigger = TriggerBuilder.newTrigger()
                .withIdentity(UUID.randomUUID().toString(), "application-group")
//                .forJob(job)
                .withDescription("A simple trigger")
//                .startAt(startAt)
                .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(10).withRepeatCount(3))
                .build();

        scheduler.scheduleJob(job, trigger);
        System.out.println("TimerEventBean - setTimer[out]");
    }

    @PreDestroy
    public void destroy() throws SchedulerException {
        System.out.println("TimerEventBean - destroy");
        scheduler.shutdown();
    }
}
