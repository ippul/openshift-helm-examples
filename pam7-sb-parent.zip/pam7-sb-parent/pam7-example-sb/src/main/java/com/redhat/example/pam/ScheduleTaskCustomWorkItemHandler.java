package com.redhat.example.pam;

import com.redhat.example.pam.timers.TimerEventBean;
import org.jbpm.process.workitem.core.util.Wid;
import org.jbpm.process.workitem.core.util.WidMavenDepends;
import org.jbpm.process.workitem.core.util.service.WidAction;
import org.jbpm.process.workitem.core.util.service.WidService;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemHandler;
import org.kie.api.runtime.process.WorkItemManager;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("ScheduleTask")
//@Wid(widfile = "WidScheduleTask.wid", name = "ScheduleTask",
//        displayName = "WidCustom",
//        defaultHandler = "mvel: new com.redhat.example.pam.ScheduleTaskCustomWorkItemHandler()",
//        mavenDepends = {
//                @WidMavenDepends(group = "${groupId}", artifact = "${artifactId}", version = "${version}")
//        },
//        serviceInfo = @WidService(category = "${name}", description = "${description}",
//                keywords = "Schedule a task",
//                action = @WidAction(title = "Schedule a task")
//        ))
public class ScheduleTaskCustomWorkItemHandler implements WorkItemHandler {

    @Autowired
    private TimerEventBean timerEventBean;

    @Override
    public void executeWorkItem(WorkItem workItem, WorkItemManager manager) {
        try {
            timerEventBean.setTimer();
            System.out.println("Task scheduled!");
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
        manager.completeWorkItem(workItem.getId(), null);
    }

    @Override
    public void abortWorkItem(WorkItem workItem, WorkItemManager manager) {
        manager.abortWorkItem(workItem.getId());
    }
}
